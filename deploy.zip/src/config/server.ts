const serverConfig = {
  PORT: process.env.PORT as string,
  JWT_SECRET: process.env.JWT_SECRET as string,
};

export default serverConfig;
