export type RolesEnum = Roles.ADMIN | Roles.USER;

export enum Roles {
  ADMIN = "ADMIN",
  USER = "USER",
}
