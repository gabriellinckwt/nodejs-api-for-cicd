const dbConfig = {
  AWS_ACCESS_KEY_ID: "AKIAVRUVRVIM6262WC6S",
  AWS_SECRET_ACCESS_KEY: "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",
  AWS_REGION: "us-east-1",
};

export default dbConfig;
