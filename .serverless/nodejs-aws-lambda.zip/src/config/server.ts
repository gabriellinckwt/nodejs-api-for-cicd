const serverConfig = {
  PORT: 3000,
  JWT_SECRET: "mysecret",
};

export default serverConfig;
